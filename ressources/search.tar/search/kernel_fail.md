- [ x ] dirty cow
- [ ] fusermount
- [ ] ptrace/sysret
- [ ] inode_capable


[+] [CVE-2015-3202] fuse (fusermount)

   Details: http://seclists.org/oss-sec/2015/q2/520
   Exposure: probable
   Tags: debian=7.0|8.0,[ ubuntu=* ]
   Download URL: https://www.exploit-db.com/download/37089
   Comments: Needs cron or system admin interaction

[+] [CVE-2014-4699] ptrace/sysret

   Details: http://www.openwall.com/lists/oss-security/2014/07/08/16
   Exposure: probable
   Tags: [ ubuntu=12.04 ]
   Download URL: https://www.exploit-db.com/download/34134

[+] [CVE-2014-4014] inode_capable

   Details: http://www.openwall.com/lists/oss-security/2014/06/10/4
   Exposure: probable
   Tags: [ ubuntu=12.04 ]
   Download URL: https://www.exploit-db.com/download/33824
